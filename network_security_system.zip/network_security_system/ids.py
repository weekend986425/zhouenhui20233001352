# -*- coding: utf-8 -*-
"""
入侵检测系统(IDS)模块 - 检测典型攻击流量
"""
import json
import logging
import re
from datetime import datetime
from typing import Dict, List, Tuple
import os
from config import IDS_RULES_FILE, IDS_LOG

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(IDS_LOG, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('IDS')


class IntrusionDetectionSystem:
    """入侵检测系统类"""
    
    def __init__(self):
        self.rules = self.load_rules()
        self.alerts = []
        self.attack_signatures = {
            'sql_injection': [
                r"('|(\\')|(;)|(--)|(/\*)|(\*/)|(\+)|(\%)|(\=))",
                r"(union|select|insert|update|delete|drop|create|alter|exec|execute)",
                r"(\bor\b\s+\d+\s*=\s*\d+)",
                r"(\band\b\s+\d+\s*=\s*\d+)"
            ],
            'xss': [
                r"<script[^>]*>.*?</script>",
                r"javascript:",
                r"onerror\s*=",
                r"onload\s*=",
                r"onclick\s*=",
                r"<iframe[^>]*>",
                r"<img[^>]*onerror"
            ],
            'command_injection': [
                r"[;&|`$(){}]",
                r"(cat|ls|pwd|whoami|id|uname|ps|netstat)\s",
                r"(rm|del|mv|cp|chmod|chown)\s",
                r"(wget|curl|nc|netcat)\s"
            ],
            'path_traversal': [
                r"\.\./",
                r"\.\.\\",
                r"/etc/passwd",
                r"/etc/shadow",
                r"c:\\windows\\system32"
            ],
            'brute_force': {
                'threshold': 5,
                'window': 300  # 5分钟
            }
        }
        self.request_history = {}  # 跟踪请求历史
        
    def load_rules(self) -> List[Dict]:
        """加载IDS规则"""
        default_rules = [
            {
                'id': 1,
                'name': 'SQL注入检测',
                'attack_type': 'sql_injection',
                'severity': 'high',
                'enabled': True
            },
            {
                'id': 2,
                'name': 'XSS攻击检测',
                'attack_type': 'xss',
                'severity': 'high',
                'enabled': True
            },
            {
                'id': 3,
                'name': '命令注入检测',
                'attack_type': 'command_injection',
                'severity': 'critical',
                'enabled': True
            },
            {
                'id': 4,
                'name': '路径遍历检测',
                'attack_type': 'path_traversal',
                'severity': 'high',
                'enabled': True
            },
            {
                'id': 5,
                'name': '暴力破解检测',
                'attack_type': 'brute_force',
                'severity': 'medium',
                'enabled': True
            }
        ]
        
        if os.path.exists(IDS_RULES_FILE):
            try:
                with open(IDS_RULES_FILE, 'r', encoding='utf-8') as f:
                    rules = json.load(f)
                    return rules if rules else default_rules
            except Exception as e:
                logger.error(f"加载IDS规则失败: {e}")
                return default_rules
        else:
            self.save_rules(default_rules)
            return default_rules
    
    def save_rules(self, rules: List[Dict] = None):
        """保存IDS规则"""
        if rules is None:
            rules = self.rules
        try:
            with open(IDS_RULES_FILE, 'w', encoding='utf-8') as f:
                json.dump(rules, f, ensure_ascii=False, indent=2)
            logger.info("IDS规则已保存")
        except Exception as e:
            logger.error(f"保存IDS规则失败: {e}")
    
    def detect_attack(self, src_ip: str, data: str, request_type: str = 'http') -> Tuple[bool, str, str]:
        """
        检测攻击
        返回: (是否检测到攻击, 攻击类型, 详细信息)
        """
        if not data:
            return False, '', ''
        
        data_lower = data.lower()
        
        # 检查SQL注入
        if self._check_sql_injection(data):
            # 安全地截断和清理消息，避免XSS payload在Web界面执行
            safe_data = data[:80].replace('<', '&lt;').replace('>', '&gt;')
            alert = f"检测到SQL注入攻击来自 {src_ip}: {safe_data}"
            logger.critical(alert)
            self.add_alert('sql_injection', 'high', src_ip, alert)
            return True, 'sql_injection', alert
        
        # 检查XSS
        if self._check_xss(data):
            # 安全地截断和清理消息，避免XSS payload在Web界面执行
            safe_data = data[:80].replace('<', '&lt;').replace('>', '&gt;')
            alert = f"检测到XSS攻击来自 {src_ip}: {safe_data}"
            logger.critical(alert)
            self.add_alert('xss', 'high', src_ip, alert)
            return True, 'xss', alert
        
        # 检查命令注入
        if self._check_command_injection(data):
            # 安全地截断和清理消息
            safe_data = data[:80].replace('<', '&lt;').replace('>', '&gt;')
            alert = f"检测到命令注入攻击来自 {src_ip}: {safe_data}"
            logger.critical(alert)
            self.add_alert('command_injection', 'critical', src_ip, alert)
            return True, 'command_injection', alert
        
        # 检查路径遍历
        if self._check_path_traversal(data):
            # 安全地截断和清理消息
            safe_data = data[:80].replace('<', '&lt;').replace('>', '&gt;')
            alert = f"检测到路径遍历攻击来自 {src_ip}: {safe_data}"
            logger.critical(alert)
            self.add_alert('path_traversal', 'high', src_ip, alert)
            return True, 'path_traversal', alert
        
        return False, '', ''
    
    def _check_sql_injection(self, data: str) -> bool:
        """检查SQL注入"""
        patterns = self.attack_signatures['sql_injection']
        for pattern in patterns:
            if re.search(pattern, data, re.IGNORECASE):
                return True
        return False
    
    def _check_xss(self, data: str) -> bool:
        """检查XSS攻击"""
        patterns = self.attack_signatures['xss']
        for pattern in patterns:
            if re.search(pattern, data, re.IGNORECASE):
                return True
        return False
    
    def _check_command_injection(self, data: str) -> bool:
        """检查命令注入"""
        patterns = self.attack_signatures['command_injection']
        for pattern in patterns:
            if re.search(pattern, data, re.IGNORECASE):
                return True
        return False
    
    def _check_path_traversal(self, data: str) -> bool:
        """检查路径遍历"""
        patterns = self.attack_signatures['path_traversal']
        for pattern in patterns:
            if re.search(pattern, data, re.IGNORECASE):
                return True
        return False
    
    def detect_brute_force(self, src_ip: str, success: bool = False) -> bool:
        """检测暴力破解攻击"""
        pattern = self.attack_signatures['brute_force']
        current_time = datetime.now().timestamp()
        
        if src_ip not in self.request_history:
            self.request_history[src_ip] = {'failed_attempts': []}
        
        if success:
            # 成功登录，清除失败记录
            self.request_history[src_ip]['failed_attempts'] = []
            return False
        
        # 记录失败尝试
        self.request_history[src_ip]['failed_attempts'].append(current_time)
        
        # 清理旧记录
        self.request_history[src_ip]['failed_attempts'] = [
            t for t in self.request_history[src_ip]['failed_attempts']
            if current_time - t < pattern['window']
        ]
        
        # 检查是否超过阈值
        if len(self.request_history[src_ip]['failed_attempts']) >= pattern['threshold']:
            alert = f"检测到暴力破解攻击来自 {src_ip}"
            logger.critical(alert)
            self.add_alert('brute_force', 'medium', src_ip, alert)
            return True
        return False
    
    def add_alert(self, attack_type: str, severity: str, src_ip: str, message: str):
        """添加警报"""
        alert = {
            'timestamp': datetime.now().isoformat(),
            'attack_type': attack_type,
            'severity': severity,
            'src_ip': src_ip,
            'message': message
        }
        self.alerts.append(alert)
        # 只保留最近1000条警报
        if len(self.alerts) > 1000:
            self.alerts = self.alerts[-1000:]
    
    def get_alerts(self, limit: int = 100) -> List[Dict]:
        """获取最近的警报"""
        return self.alerts[-limit:]
    
    def get_statistics(self) -> Dict:
        """获取IDS统计信息"""
        alert_counts = {}
        for alert in self.alerts:
            attack_type = alert['attack_type']
            alert_counts[attack_type] = alert_counts.get(attack_type, 0) + 1
        
        return {
            'total_alerts': len(self.alerts),
            'alert_counts': alert_counts,
            'rules_count': len(self.rules),
            'active_rules': len([r for r in self.rules if r.get('enabled', True)])
        }


# 全局IDS实例
ids = IntrusionDetectionSystem()

