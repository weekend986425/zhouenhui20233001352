# -*- coding: utf-8 -*-
"""
攻击测试脚本 - Spyder专用版本（自动运行，无需输入）
"""
import requests
import time
import socket
from datetime import datetime

# 配置 - 自动检测IP地址
def get_local_ip():
    """获取本机IP地址"""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except:
        return '127.0.0.1'

# 自动设置BASE_URL
LOCAL_IP = get_local_ip()
BASE_URL = f'http://{LOCAL_IP}:8080'  # 自动使用本机IP
API_BASE = f'{BASE_URL}/api'

print(f"使用服务器地址: {BASE_URL}")
print("如果连接失败，请手动修改BASE_URL\n")


class AttackTester:
    """攻击测试类"""
    
    def __init__(self):
        self.results = []
        
    def test_sql_injection(self):
        """测试SQL注入攻击"""
        print("\n[测试] SQL注入攻击检测")
        payloads = [
            "' OR '1'='1",
            "'; DROP TABLE users; --",
            "1' UNION SELECT * FROM users--",
            "admin'--",
            "' OR 1=1--"
        ]
        
        for payload in payloads:
            try:
                response = requests.post(
                    f'{API_BASE}/ids/detect',
                    json={'payload': payload, 'src_ip': '192.168.1.100'},
                    timeout=5
                )
                result = response.json()
                status = "✓ 检测到" if result.get('detected') else "✗ 未检测到"
                print(f"  {status}: {payload[:30]}")
                self.results.append(('SQL注入', payload, result.get('detected')))
            except Exception as e:
                print(f"  错误: {e}")
    
    def test_xss(self):
        """测试XSS攻击"""
        print("\n[测试] XSS攻击检测")
        payloads = [
            "<script>alert('XSS')</script>",
            "<img src=x onerror=alert('XSS')>",
            "javascript:alert('XSS')",
            "<iframe src='javascript:alert(1)'></iframe>"
        ]
        
        for payload in payloads:
            try:
                response = requests.post(
                    f'{API_BASE}/ids/detect',
                    json={'payload': payload, 'src_ip': '192.168.1.100'},
                    timeout=5
                )
                result = response.json()
                status = "✓ 检测到" if result.get('detected') else "✗ 未检测到"
                print(f"  {status}: {payload[:30]}")
                self.results.append(('XSS', payload, result.get('detected')))
            except Exception as e:
                print(f"  错误: {e}")
    
    def test_command_injection(self):
        """测试命令注入攻击"""
        print("\n[测试] 命令注入攻击检测")
        payloads = [
            "; cat /etc/passwd",
            "| ls -la",
            "`whoami`",
            "&& netstat -an"
        ]
        
        for payload in payloads:
            try:
                response = requests.post(
                    f'{API_BASE}/ids/detect',
                    json={'payload': payload, 'src_ip': '192.168.1.100'},
                    timeout=5
                )
                result = response.json()
                status = "✓ 检测到" if result.get('detected') else "✗ 未检测到"
                print(f"  {status}: {payload[:30]}")
                self.results.append(('命令注入', payload, result.get('detected')))
            except Exception as e:
                print(f"  错误: {e}")
    
    def test_port_scan(self):
        """测试端口扫描检测"""
        print("\n[测试] 端口扫描检测")
        target_ip = LOCAL_IP
        
        # 模拟端口扫描 - 通过API触发检测
        ports_to_scan = [80, 443, 22, 21, 23, 25, 53, 3306, 8080]
        
        print(f"  正在扫描 {len(ports_to_scan)} 个端口...")
        detected_count = 0
        
        for port in ports_to_scan:
            try:
                # 通过API触发端口扫描检测
                response = requests.post(
                    f'{API_BASE}/firewall/detect_port_scan',
                    json={'src_ip': target_ip, 'dst_port': port},
                    timeout=2
                )
                if response.status_code == 200:
                    result = response.json()
                    if isinstance(result, dict) and result.get('detected'):
                        detected_count += 1
                time.sleep(0.1)  # 短暂延迟模拟真实扫描
            except Exception as e:
                # 静默处理，继续扫描
                pass
        
        time.sleep(1)
        
        # 检查是否被阻止
        try:
            response = requests.get(f'{API_BASE}/firewall/blocked', timeout=5)
            if response.status_code == 200:
                blocked = response.json()
                if isinstance(blocked, dict) and target_ip in blocked.get('blocked_ips', []):
                    print("  ✓ 端口扫描被检测并阻止")
                else:
                    print("  ✗ 端口扫描未被检测（可能需要更多扫描）")
            else:
                print("  ✗ 端口扫描未被检测（服务器错误）")
        except Exception as e:
            print(f"  ✗ 检查阻止状态时出错: {e}")
    
    def test_syn_flood(self):
        """测试SYN Flood攻击检测"""
        print("\n[测试] SYN Flood攻击检测")
        target_ip = LOCAL_IP
        
        # 模拟SYN Flood - 通过API触发检测
        print("  发送SYN请求...")
        for i in range(15):
            try:
                # 通过API触发SYN Flood检测
                response = requests.post(
                    f'{API_BASE}/firewall/detect_syn_flood',
                    json={'src_ip': target_ip},
                    timeout=2
                )
                if response.status_code == 200:
                    result = response.json()
                    if isinstance(result, dict) and result.get('detected'):
                        print(f"  ✓ 在第 {i+1} 次请求时检测到SYN Flood攻击")
                        break
                time.sleep(0.1)  # 短暂延迟
            except Exception as e:
                # 静默处理，继续测试
                pass
        
        time.sleep(1)
        
        # 检查是否被阻止
        try:
            response = requests.get(f'{API_BASE}/firewall/blocked', timeout=5)
            if response.status_code == 200:
                blocked = response.json()
                if isinstance(blocked, dict) and target_ip in blocked.get('blocked_ips', []):
                    print("  ✓ SYN Flood被检测并阻止")
                else:
                    print("  ✗ SYN Flood未被检测（可能需要更多请求）")
            else:
                print("  ✗ SYN Flood未被检测（服务器错误）")
        except Exception as e:
            print(f"  ✗ 检查阻止状态时出错: {e}")
    
    def test_brute_force(self):
        """测试暴力破解检测"""
        print("\n[测试] 暴力破解检测")
        test_ip = LOCAL_IP
        
        # 模拟多次失败登录 - 通过API触发检测
        print("  模拟失败登录尝试...")
        detected = False
        
        for i in range(6):
            try:
                # 通过API触发暴力破解检测（success=False表示登录失败）
                response = requests.post(
                    f'{API_BASE}/ids/detect_brute_force',
                    json={'src_ip': test_ip, 'success': False},
                    timeout=2
                )
                # 检查响应状态
                if response.status_code == 200:
                    result = response.json()
                    if isinstance(result, dict) and result.get('detected'):
                        print(f"  ✓ 在第 {i+1} 次失败登录时检测到暴力破解")
                        detected = True
                        break
                time.sleep(0.5)  # 模拟真实登录间隔
            except Exception as e:
                # 静默处理错误，继续测试
                pass
        
        time.sleep(1)
        
        # 检查警报
        try:
            response = requests.get(f'{API_BASE}/ids/alerts?limit=10', timeout=5)
            if response.status_code == 200:
                alerts = response.json()
                if isinstance(alerts, list):
                    brute_force_alerts = [a for a in alerts if isinstance(a, dict) and a.get('attack_type') == 'brute_force']
                    if brute_force_alerts or detected:
                        print("  ✓ 暴力破解被检测")
                    else:
                        print("  ✗ 暴力破解未被检测（可能需要更多失败尝试）")
                else:
                    if detected:
                        print("  ✓ 暴力破解被检测")
                    else:
                        print("  ✗ 暴力破解未被检测（响应格式错误）")
            else:
                if detected:
                    print("  ✓ 暴力破解被检测")
                else:
                    print("  ✗ 暴力破解未被检测（服务器错误）")
        except Exception as e:
            if detected:
                print("  ✓ 暴力破解被检测")
            else:
                print(f"  ✗ 检查警报时出错: {e}")
    
    def test_encryption(self):
        """测试数据加密功能"""
        print("\n[测试] 数据加密/解密")
        
        test_data = "这是敏感数据: 用户名=admin, 密码=123456"
        
        try:
            # 加密
            response = requests.post(
                f'{API_BASE}/data/encrypt',
                json={'text': test_data},
                timeout=5
            )
            
            if response.status_code != 200:
                print(f"  ✗ 加密失败: HTTP {response.status_code}")
                return
            
            result = response.json()
            if not isinstance(result, dict) or not result.get('success'):
                error_msg = result.get('error', '未知错误') if isinstance(result, dict) else '响应格式错误'
                print(f"  ✗ 加密失败: {error_msg}")
                return
            
            encrypted = result.get('encrypted')
            if not encrypted:
                print("  ✗ 加密失败: 未返回加密数据")
                return
            
            print(f"  加密成功: {encrypted[:50]}...")
            
            # 解密
            response = requests.post(
                f'{API_BASE}/data/decrypt',
                json={'encrypted': encrypted},
                timeout=5
            )
            
            if response.status_code != 200:
                print(f"  ✗ 解密失败: HTTP {response.status_code}")
                return
            
            result = response.json()
            if not isinstance(result, dict) or not result.get('success'):
                error_msg = result.get('error', '未知错误') if isinstance(result, dict) else '响应格式错误'
                print(f"  ✗ 解密失败: {error_msg}")
                return
            
            decrypted = result.get('decrypted')
            if not decrypted:
                print("  ✗ 解密失败: 未返回解密数据")
                return
            
            if decrypted == test_data:
                print("  ✓ 加密/解密功能正常")
            else:
                print("  ✗ 加密/解密失败: 数据不匹配")
        except Exception as e:
            print(f"  ✗ 错误: {e}")
    
    def test_password_policy(self):
        """测试密码策略"""
        print("\n[测试] 密码策略")
        
        test_passwords = [
            ("weak", "12345"),  # 太短
            ("medium", "password123"),  # 缺少大写和特殊字符
            ("strong", "P@ssw0rd123!")  # 符合策略
        ]
        
        for name, password in test_passwords:
            try:
                response = requests.post(
                    f'{API_BASE}/host/check_password',
                    json={'password': password},
                    timeout=5
                )
                
                if response.status_code != 200:
                    print(f"  ✗ {name}: HTTP {response.status_code} 错误")
                    continue
                
                result = response.json()
                if not isinstance(result, dict):
                    print(f"  ✗ {name}: 响应格式错误")
                    continue
                
                status = "✓" if result.get('valid') else "✗"
                strength = result.get('strength', {})
                if isinstance(strength, dict):
                    level = strength.get('level', 'N/A')
                else:
                    level = 'N/A'
                print(f"  {status} {name}: {level}")
            except Exception as e:
                print(f"  ✗ {name}: {e}")
    
    def performance_test(self):
        """性能测试"""
        print("\n[测试] 性能测试")
        
        num_requests = 100
        start_time = time.time()
        
        for i in range(num_requests):
            try:
                requests.get(f'{API_BASE}/status', timeout=2)
            except:
                pass
        
        elapsed = time.time() - start_time
        rps = num_requests / elapsed
        
        print(f"  完成 {num_requests} 个请求")
        print(f"  耗时: {elapsed:.2f} 秒")
        print(f"  吞吐量: {rps:.2f} 请求/秒")
    
    def run_all_tests(self):
        """运行所有测试"""
        print("=" * 50)
        print("校园网安全防护系统 - 攻击测试")
        print("=" * 50)
        print(f"\n服务器地址: {BASE_URL}")
        print("正在检查服务器连接...")
        
        # 检查服务器是否运行
        try:
            response = requests.get(f'{API_BASE}/status', timeout=3)
            if response.status_code == 200:
                print("✓ 服务器连接成功\n")
            else:
                print(f"✗ 服务器响应异常: HTTP {response.status_code}\n")
                if response.status_code == 403:
                    print("⚠️  警告: IP可能被阻止，测试可能无法正常进行")
                    print("   建议: 在Web界面解除IP阻止，或重启服务器\n")
        except Exception as e:
            print(f"✗ 无法连接到服务器: {e}")
            print("请确保app.py或app_spyder.py正在运行！\n")
            return
        
        # 检查IP是否被阻止，如果被阻止则尝试解除
        try:
            response = requests.get(f'{API_BASE}/firewall/blocked', timeout=3)
            if response.status_code == 200:
                blocked = response.json()
                if isinstance(blocked, dict):
                    blocked_ips = blocked.get('blocked_ips', [])
                    if LOCAL_IP in blocked_ips:
                        print(f"⚠️  警告: 当前IP ({LOCAL_IP}) 已被阻止")
                        print("   正在尝试自动解除阻止...")
                        # 尝试解除阻止
                        try:
                            unblock_response = requests.post(
                                f'{API_BASE}/firewall/unblock_ip',
                                json={'ip': LOCAL_IP},
                                timeout=3
                            )
                            if unblock_response.status_code == 200:
                                print("   ✓ 已自动解除IP阻止\n")
                            else:
                                print("   ✗ 无法自动解除，请手动重启服务器\n")
                        except:
                            print("   ✗ 无法自动解除，请手动重启服务器\n")
        except:
            pass
        
        # 先测试不会触发IP阻止的功能
        self.test_sql_injection()
        self.test_xss()
        self.test_command_injection()
        
        # 测试可能触发IP阻止的功能（端口扫描和SYN Flood）
        # 这些测试可能会将IP加入阻止列表
        self.test_port_scan()
        self.test_syn_flood()
        
        # 在测试其他功能前，确保IP未被阻止
        # 如果被阻止，尝试解除
        try:
            response = requests.get(f'{API_BASE}/firewall/blocked', timeout=3)
            if response.status_code == 200:
                blocked = response.json()
                if isinstance(blocked, dict):
                    blocked_ips = blocked.get('blocked_ips', [])
                    if LOCAL_IP in blocked_ips:
                        print("\n⚠️  检测到IP被阻止，正在解除...")
                        unblock_response = requests.post(
                            f'{API_BASE}/firewall/unblock_ip',
                            json={'ip': LOCAL_IP},
                            timeout=3
                        )
                        if unblock_response.status_code == 200:
                            print("✓ IP阻止已解除，继续测试\n")
                        else:
                            print("✗ 无法解除IP阻止，部分测试可能失败\n")
        except:
            pass
        
        # 继续测试其他功能
        self.test_brute_force()
        self.test_encryption()
        self.test_password_policy()
        self.performance_test()
        
        print("\n" + "=" * 50)
        print("测试完成")
        print("=" * 50)
        
        # 统计结果
        detected = sum(1 for r in self.results if r[2])
        total = len(self.results)
        if total > 0:
            print(f"\n检测率: {detected}/{total} ({detected*100/total:.1f}%)")
        else:
            print("\n未执行任何检测测试")


if __name__ == '__main__':
    # Spyder版本：自动运行，无需输入
    print("\n" + "=" * 50)
    print("开始运行测试...")
    print("=" * 50 + "\n")
    
    tester = AttackTester()
    tester.run_all_tests()
    
    print("\n测试完成！可以查看上面的结果。")

