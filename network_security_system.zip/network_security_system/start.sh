#!/bin/bash

echo "========================================"
echo "网络安全系统启动脚本"
echo "========================================"
echo ""

echo "正在检查Python环境..."
if ! command -v python3 &> /dev/null; then
    echo "错误: 未找到Python，请先安装Python 3.7+"
    exit 1
fi

echo "正在检查依赖包..."
if ! python3 -c "import flask" 2>/dev/null; then
    echo "正在安装依赖包..."
    pip3 install -r requirements.txt
    if [ $? -ne 0 ]; then
        echo "错误: 依赖包安装失败"
        exit 1
    fi
fi

echo ""
echo "正在启动服务器..."
echo ""
python3 app.py

