# -*- coding: utf-8 -*-
"""
主机安全模块 - 密码策略、端口服务等安全配置
"""
import json
import logging
import socket
import subprocess
import platform
import re
from datetime import datetime
from typing import Dict, List, Tuple
import os
from config import PASSWORD_POLICY, SECURITY_LOG

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(SECURITY_LOG, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('HostSecurity')


class HostSecurity:
    """主机安全类"""
    
    def __init__(self):
        self.password_policy = PASSWORD_POLICY
        self.open_ports = []
        self.running_services = []
        self.security_config = {}
        
    def validate_password(self, password: str) -> Tuple[bool, List[str]]:
        """
        验证密码是否符合策略
        返回: (是否有效, 错误列表)
        """
        errors = []
        
        if len(password) < self.password_policy['min_length']:
            errors.append(f"密码长度至少需要 {self.password_policy['min_length']} 个字符")
        
        if self.password_policy['require_uppercase'] and not re.search(r'[A-Z]', password):
            errors.append("密码必须包含至少一个大写字母")
        
        if self.password_policy['require_lowercase'] and not re.search(r'[a-z]', password):
            errors.append("密码必须包含至少一个小写字母")
        
        if self.password_policy['require_digits'] and not re.search(r'\d', password):
            errors.append("密码必须包含至少一个数字")
        
        if self.password_policy['require_special'] and not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            errors.append("密码必须包含至少一个特殊字符")
        
        return len(errors) == 0, errors
    
    def calculate_password_strength(self, password: str) -> Dict:
        """计算密码强度"""
        strength = 0
        feedback = []
        
        if len(password) >= 8:
            strength += 1
        else:
            feedback.append("密码长度建议至少8位")
        
        if len(password) >= 12:
            strength += 1
        
        if re.search(r'[A-Z]', password):
            strength += 1
        else:
            feedback.append("建议包含大写字母")
        
        if re.search(r'[a-z]', password):
            strength += 1
        else:
            feedback.append("建议包含小写字母")
        
        if re.search(r'\d', password):
            strength += 1
        else:
            feedback.append("建议包含数字")
        
        if re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
            strength += 1
        else:
            feedback.append("建议包含特殊字符")
        
        if len(password) >= 16:
            strength += 1
        
        strength_levels = ['很弱', '弱', '一般', '较强', '强', '很强', '极强']
        level = strength_levels[min(strength, len(strength_levels) - 1)]
        
        return {
            'strength': strength,
            'level': level,
            'feedback': feedback
        }
    
    def scan_local_ports(self, port_range: Tuple[int, int] = (1, 1024)) -> List[Dict]:
        """扫描本地开放端口"""
        open_ports = []
        start_port, end_port = port_range
        
        logger.info(f"开始扫描本地端口 {start_port}-{end_port}")
        
        for port in range(start_port, min(end_port + 1, 65536)):
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(0.1)
                result = sock.connect_ex(('127.0.0.1', port))
                if result == 0:
                    service_name = self._get_service_name(port)
                    open_ports.append({
                        'port': port,
                        'service': service_name,
                        'status': 'open'
                    })
                    logger.info(f"发现开放端口: {port} ({service_name})")
                sock.close()
            except Exception as e:
                pass
        
        self.open_ports = open_ports
        return open_ports
    
    def _get_service_name(self, port: int) -> str:
        """获取端口对应的服务名称"""
        common_ports = {
            21: 'FTP',
            22: 'SSH',
            23: 'Telnet',
            25: 'SMTP',
            53: 'DNS',
            80: 'HTTP',
            110: 'POP3',
            143: 'IMAP',
            443: 'HTTPS',
            3306: 'MySQL',
            5432: 'PostgreSQL',
            8080: 'HTTP-Proxy',
            3389: 'RDP'
        }
        return common_ports.get(port, 'Unknown')
    
    def check_port_security(self, ports: List[int] = None) -> Dict:
        """检查端口安全性"""
        if ports is None:
            ports = [p['port'] for p in self.open_ports]
        
        dangerous_ports = {
            23: 'Telnet - 明文传输，不安全',
            135: 'RPC - 可能存在漏洞',
            139: 'NetBIOS - 可能存在漏洞',
            445: 'SMB - 可能存在漏洞',
            1433: 'SQL Server - 需要强密码',
            3306: 'MySQL - 需要强密码',
            5432: 'PostgreSQL - 需要强密码',
            3389: 'RDP - 需要强密码和加密'
        }
        
        insecure_ports = []
        for port in ports:
            if port in dangerous_ports:
                insecure_ports.append({
                    'port': port,
                    'risk': 'high',
                    'description': dangerous_ports[port]
                })
        
        return {
            'total_ports': len(ports),
            'insecure_ports': insecure_ports,
            'recommendations': self._get_port_recommendations(insecure_ports)
        }
    
    def _get_port_recommendations(self, insecure_ports: List[Dict]) -> List[str]:
        """获取端口安全建议"""
        recommendations = []
        
        if any(p['port'] == 23 for p in insecure_ports):
            recommendations.append("建议关闭Telnet(23)端口，使用SSH(22)替代")
        
        if any(p['port'] in [135, 139, 445] for p in insecure_ports):
            recommendations.append("建议关闭不必要的SMB/RPC端口(135,139,445)，或限制访问")
        
        if any(p['port'] in [1433, 3306, 5432] for p in insecure_ports):
            recommendations.append("数据库端口应配置强密码和IP白名单")
        
        if any(p['port'] == 3389 for p in insecure_ports):
            recommendations.append("RDP端口应启用网络级身份验证(NLA)和强密码")
        
        return recommendations
    
    def get_system_info(self) -> Dict:
        """获取系统信息"""
        system_info = {
            'platform': platform.system(),
            'platform_version': platform.version(),
            'architecture': platform.machine(),
            'processor': platform.processor(),
            'hostname': socket.gethostname()
        }
        
        try:
            # 获取IP地址
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            system_info['local_ip'] = s.getsockname()[0]
            s.close()
        except:
            system_info['local_ip'] = '127.0.0.1'
        
        return system_info
    
    def get_security_status(self) -> Dict:
        """获取安全状态"""
        return {
            'password_policy': self.password_policy,
            'open_ports_count': len(self.open_ports),
            'open_ports': self.open_ports,
            'system_info': self.get_system_info()
        }


# 全局主机安全实例
host_security = HostSecurity()

