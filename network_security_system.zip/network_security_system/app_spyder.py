# -*- coding: utf-8 -*-
"""
网络安全系统主程序 - Spyder专用版本
在Spyder中运行此文件，而不是app.py
"""
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import socket

from config import SERVER_HOST, SERVER_PORT
from firewall import firewall
from ids import ids
from host_security import host_security
from data_security import data_security

app = Flask(__name__)
CORS(app)

# 全局状态
from datetime import datetime
system_status = {
    'running': True,
    'start_time': datetime.now().isoformat()
}


@app.before_request
def check_firewall():
    """在每次请求前检查防火墙规则"""
    # 允许某些API通过，用于管理和测试
    allowed_paths = [
        '/api/firewall/blocked',  # 获取阻止列表
        '/api/firewall/block_ip',  # 阻止IP（管理功能）
        '/api/firewall/unblock_ip',  # 解除IP阻止（管理功能）
        '/api/status',  # 系统状态
        # 测试相关API，允许通过以便测试功能
        '/api/ids/detect_brute_force',  # 暴力破解检测（测试功能）
        '/api/data/encrypt',  # 数据加密（测试功能）
        '/api/data/decrypt',  # 数据解密（测试功能）
        '/api/host/check_password',  # 密码策略检查（测试功能）
    ]
    
    # 如果是允许的路径，直接通过
    if request.path in allowed_paths:
        return None
    
    # 获取客户端IP地址
    client_ip = request.remote_addr
    
    # 如果是通过代理，尝试获取真实IP
    if request.headers.get('X-Forwarded-For'):
        client_ip = request.headers.get('X-Forwarded-For').split(',')[0].strip()
    
    # 检查IP是否被阻止
    if client_ip in firewall.blocked_ips:
        # 记录阻止日志
        from firewall import logger
        logger.warning(f"阻止来自被阻止IP的请求: {client_ip}, 路径: {request.path}")
        # 返回403禁止访问
        return jsonify({
            'error': 'Forbidden',
            'message': f'IP {client_ip} 已被阻止',
            'reason': '该IP地址在防火墙黑名单中'
        }), 403


@app.route('/')
def index():
    """主页面"""
    return render_template('index.html')


@app.route('/api/status')
def get_status():
    """获取系统状态"""
    return jsonify({
        'status': 'running',
        'start_time': system_status['start_time'],
        'firewall': firewall.get_statistics(),
        'ids': ids.get_statistics(),
        'host_security': host_security.get_security_status()
    })


@app.route('/api/firewall/rules', methods=['GET'])
def get_firewall_rules():
    """获取防火墙规则"""
    return jsonify(firewall.rules)


@app.route('/api/firewall/rules', methods=['POST'])
def add_firewall_rule():
    """添加防火墙规则"""
    data = request.json
    new_rule = {
        'id': len(firewall.rules) + 1,
        'name': data.get('name', '新规则'),
        'action': data.get('action', 'block'),
        'enabled': data.get('enabled', True)
    }
    
    if 'ports' in data:
        new_rule['ports'] = data['ports']
    if 'ips' in data:
        new_rule['ips'] = data['ips']
    
    firewall.rules.append(new_rule)
    firewall.save_rules()
    return jsonify({'success': True, 'rule': new_rule})


@app.route('/api/firewall/blocked', methods=['GET'])
def get_blocked():
    """获取被阻止的IP和端口"""
    return jsonify({
        'blocked_ips': list(firewall.blocked_ips),
        'blocked_ports': list(firewall.blocked_ports)
    })


@app.route('/api/firewall/block_ip', methods=['POST'])
def block_ip():
    """阻止IP"""
    data = request.json
    ip = data.get('ip')
    reason = data.get('reason', '手动阻止')
    firewall.block_ip(ip, reason)
    return jsonify({'success': True})


@app.route('/api/firewall/unblock_ip', methods=['POST'])
def unblock_ip():
    """解除IP阻止"""
    data = request.json
    ip = data.get('ip')
    if ip:
        firewall.unblock_ip(ip)
        return jsonify({'success': True, 'message': f'已解除IP {ip} 的阻止'})
    return jsonify({'success': False, 'error': '未提供IP地址'}), 400


@app.route('/api/firewall/detect_port_scan', methods=['POST'])
def detect_port_scan():
    """检测端口扫描（通过API触发）"""
    data = request.json
    src_ip = data.get('src_ip', request.remote_addr)
    dst_port = data.get('dst_port', 80)
    
    detected = firewall.detect_port_scan(src_ip, dst_port)
    return jsonify({
        'detected': detected,
        'src_ip': src_ip,
        'dst_port': dst_port
    })


@app.route('/api/firewall/detect_syn_flood', methods=['POST'])
def detect_syn_flood():
    """检测SYN Flood（通过API触发）"""
    data = request.json
    src_ip = data.get('src_ip', request.remote_addr)
    
    detected = firewall.detect_syn_flood(src_ip)
    return jsonify({
        'detected': detected,
        'src_ip': src_ip
    })


@app.route('/api/ids/rules', methods=['GET'])
def get_ids_rules():
    """获取IDS规则"""
    return jsonify(ids.rules)


@app.route('/api/ids/alerts', methods=['GET'])
def get_ids_alerts():
    """获取IDS警报"""
    limit = request.args.get('limit', 100, type=int)
    return jsonify(ids.get_alerts(limit))


@app.route('/api/ids/detect', methods=['POST'])
def detect_attack():
    """检测攻击"""
    data = request.json
    src_ip = data.get('src_ip', request.remote_addr)
    payload = data.get('payload', '')
    
    detected, attack_type, message = ids.detect_attack(src_ip, payload)
    
    return jsonify({
        'detected': detected,
        'attack_type': attack_type,
        'message': message
    })


@app.route('/api/ids/detect_brute_force', methods=['POST'])
def detect_brute_force():
    """检测暴力破解（通过API触发）"""
    data = request.json
    src_ip = data.get('src_ip', request.remote_addr)
    success = data.get('success', False)  # 是否登录成功
    
    detected = ids.detect_brute_force(src_ip, success)
    return jsonify({
        'detected': detected,
        'src_ip': src_ip
    })


@app.route('/api/host/scan_ports', methods=['POST'])
def scan_ports():
    """扫描端口"""
    data = request.json
    start_port = data.get('start_port', 1)
    end_port = data.get('end_port', 1024)
    
    open_ports = host_security.scan_local_ports((start_port, end_port))
    return jsonify({'open_ports': open_ports})


@app.route('/api/host/check_password', methods=['POST'])
def check_password():
    """检查密码"""
    data = request.json
    password = data.get('password', '')
    
    is_valid, errors = host_security.validate_password(password)
    strength = host_security.calculate_password_strength(password)
    
    return jsonify({
        'valid': is_valid,
        'errors': errors,
        'strength': strength
    })


@app.route('/api/host/port_security', methods=['GET'])
def check_port_security():
    """检查端口安全"""
    ports = request.args.get('ports', None)
    if ports:
        ports = [int(p) for p in ports.split(',')]
    
    security_info = host_security.check_port_security(ports)
    return jsonify(security_info)


@app.route('/api/data/encrypt', methods=['POST'])
def encrypt_data():
    """加密数据"""
    data = request.json
    text = data.get('text', '')
    
    try:
        encrypted = data_security.encrypt_data(text)
        return jsonify({'success': True, 'encrypted': encrypted})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


@app.route('/api/data/decrypt', methods=['POST'])
def decrypt_data():
    """解密数据"""
    data = request.json
    encrypted = data.get('encrypted', '')
    
    try:
        decrypted = data_security.decrypt_data(encrypted)
        return jsonify({'success': True, 'decrypted': decrypted})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


@app.route('/api/data/hash_password', methods=['POST'])
def hash_password():
    """哈希密码"""
    data = request.json
    password = data.get('password', '')
    
    try:
        result = data_security.hash_password(password)
        return jsonify({'success': True, 'hash': result})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 400


if __name__ == '__main__':
    try:
        # 获取本机IP
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(('8.8.8.8', 80))
            local_ip = s.getsockname()[0]
            s.close()
        except:
            local_ip = socket.gethostbyname(socket.gethostname())
        
        print(f"""
    ========================================
    校园网安全防护系统启动中...
    访问地址: http://{local_ip}:{SERVER_PORT}
    本地访问: http://127.0.0.1:{SERVER_PORT}
    ========================================
    提示: 服务器正在运行，不要关闭此窗口
    要停止服务器，请点击Spyder的"停止"按钮
    ========================================
        """)
        
        # Spyder专用：禁用reloader和debug模式的部分功能
        app.run(
            host=SERVER_HOST, 
            port=SERVER_PORT, 
            debug=False,  # 在Spyder中禁用debug模式
            use_reloader=False,  # 禁用自动重载
            threaded=True
        )
    except KeyboardInterrupt:
        print("\n服务器已停止")
    except Exception as e:
        print(f"\n启动失败: {e}")
        import traceback
        traceback.print_exc()

