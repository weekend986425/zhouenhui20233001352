
# -*- coding: utf-8 -*-
"""
演示脚本 - 展示系统各项功能
"""
from firewall import firewall
from ids import ids
from host_security import host_security
from data_security import data_security

def demo_firewall():
    """演示防火墙功能"""
    print("\n" + "="*50)
    print("防火墙模块演示")
    print("="*50)
    
    # 显示当前规则
    print("\n当前防火墙规则:")
    for rule in firewall.rules:
        print(f"  - {rule['name']}: {rule['action']} (启用: {rule.get('enabled', True)})")
    
    # 测试包检查
    print("\n测试包过滤:")
    test_cases = [
        ("192.168.1.100", 80, "正常HTTP请求"),
        ("192.168.1.100", 23, "Telnet请求（应被阻止）"),
        ("192.168.1.100", 445, "SMB请求（应被阻止）"),
    ]
    
    for src_ip, port, desc in test_cases:
        allowed, reason = firewall.check_packet(src_ip, port)
        status = "✓ 允许" if allowed else "✗ 阻止"
        print(f"  {status}: {desc} - {reason}")
    
    # 显示统计
    stats = firewall.get_statistics()
    print(f"\n防火墙统计:")
    print(f"  - 阻止IP数: {stats['blocked_ips_count']}")
    print(f"  - 阻止端口数: {stats['blocked_ports_count']}")
    print(f"  - 规则数: {stats['rules_count']}")


def demo_ids():
    """演示IDS功能"""
    print("\n" + "="*50)
    print("入侵检测系统(IDS)演示")
    print("="*50)
    
    # 显示当前规则
    print("\n当前IDS规则:")
    for rule in ids.rules:
        print(f"  - {rule['name']}: {rule['attack_type']} (严重性: {rule['severity']})")
    
    # 测试攻击检测
    print("\n测试攻击检测:")
    test_attacks = [
        ("' OR '1'='1", "SQL注入"),
        ("<script>alert('XSS')</script>", "XSS攻击"),
        ("; cat /etc/passwd", "命令注入"),
        ("../../../etc/passwd", "路径遍历"),
        ("正常数据", "正常请求"),
    ]
    
    for payload, attack_type in test_attacks:
        detected, detected_type, message = ids.detect_attack("192.168.1.100", payload)
        if detected:
            print(f"  ✗ 检测到攻击: {attack_type} - {detected_type}")
        else:
            print(f"  ✓ 正常: {attack_type}")
    
    # 显示统计
    stats = ids.get_statistics()
    print(f"\nIDS统计:")
    print(f"  - 总警报数: {stats['total_alerts']}")
    print(f"  - 规则数: {stats['rules_count']}")
    if stats['alert_counts']:
        print(f"  - 攻击类型统计:")
        for attack_type, count in stats['alert_counts'].items():
            print(f"    * {attack_type}: {count}")


def demo_host_security():
    """演示主机安全功能"""
    print("\n" + "="*50)
    print("主机安全模块演示")
    print("="*50)
    
    # 测试密码策略
    print("\n测试密码策略:")
    test_passwords = [
        "12345",  # 弱密码
        "password",  # 中等密码
        "Password123",  # 较强密码
        "P@ssw0rd123!",  # 强密码
    ]
    
    for pwd in test_passwords:
        is_valid, errors = host_security.validate_password(pwd)
        strength = host_security.calculate_password_strength(pwd)
        status = "✓" if is_valid else "✗"
        print(f"  {status} '{pwd}': {strength['level']} (强度: {strength['strength']}/6)")
        if errors:
            for err in errors:
                print(f"    - {err}")
    
    # 显示系统信息
    print("\n系统信息:")
    sys_info = host_security.get_system_info()
    for key, value in sys_info.items():
        print(f"  - {key}: {value}")
    
    # 端口扫描（仅扫描常用端口）
    print("\n扫描常用端口 (1-100):")
    open_ports = host_security.scan_local_ports((1, 100))
    if open_ports:
        print(f"  发现 {len(open_ports)} 个开放端口:")
        for port_info in open_ports[:10]:  # 只显示前10个
            print(f"    - 端口 {port_info['port']}: {port_info['service']}")
    else:
        print("  未发现开放端口")


def demo_data_security():
    """演示数据安全功能"""
    print("\n" + "="*50)
    print("数据安全模块演示")
    print("="*50)
    
    # 测试数据加密
    print("\n测试数据加密/解密:")
    test_data = "这是敏感数据: 用户名=admin, 密码=secret123"
    print(f"  原始数据: {test_data}")
    
    try:
        encrypted = data_security.encrypt_data(test_data)
        print(f"  加密后: {encrypted[:50]}...")
        
        decrypted = data_security.decrypt_data(encrypted)
        print(f"  解密后: {decrypted}")
        
        if decrypted == test_data:
            print("  ✓ 加密/解密成功")
        else:
            print("  ✗ 加密/解密失败")
    except Exception as e:
        print(f"  ✗ 错误: {e}")
    
    # 测试密码哈希
    print("\n测试密码哈希:")
    password = "MySecurePassword123!"
    hash_result = data_security.hash_password(password)
    print(f"  密码: {password}")
    print(f"  哈希值: {hash_result['hash'][:50]}...")
    print(f"  盐值: {hash_result['salt']}")
    
    # 验证密码
    is_valid = data_security.verify_password(
        password, 
        hash_result['hash'], 
        hash_result['salt']
    )
    if is_valid:
        print("  ✓ 密码验证成功")
    else:
        print("  ✗ 密码验证失败")
    
    # 测试错误密码
    is_valid_wrong = data_security.verify_password(
        "WrongPassword", 
        hash_result['hash'], 
        hash_result['salt']
    )
    if not is_valid_wrong:
        print("  ✓ 错误密码被正确拒绝")
    else:
        print("  ✗ 错误密码验证失败")


def main():
    """主函数"""
    print("\n" + "="*50)
    print("校园网安全防护系统 - 功能演示")
    print("="*50)
    print("\n本演示将展示系统的四大核心模块:")
    print("1. 防火墙配置")
    print("2. 入侵检测系统")
    print("3. 主机安全")
    print("4. 数据安全")
    
    input("\n按Enter键开始演示...")
    
    demo_firewall()
    demo_ids()
    demo_host_security()
    demo_data_security()
    
    print("\n" + "="*50)
    print("演示完成！")
    print("="*50)
    print("\n提示:")
    print("- 运行 'python app.py' 启动Web服务器")
    print("- 运行 'python test_attacks.py' 进行攻击测试")
    print("- 查看 README.md 了解详细使用方法")


if __name__ == '__main__':
    main()

