# -*- coding: utf-8 -*-
"""
数据安全模块 - 实现数据加密传输和存储
"""
import json
import logging
import os
import base64
from datetime import datetime
from typing import Dict, Any
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.backends import default_backend
from config import ENCRYPTION_KEY_FILE, ENCRYPTED_DIR

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger('DataSecurity')


class DataSecurity:
    """数据安全类 - 实现加密传输和存储"""
    
    def __init__(self):
        self.key = self._load_or_generate_key()
        self.cipher = Fernet(self.key)
        
    def _load_or_generate_key(self) -> bytes:
        """加载或生成加密密钥"""
        if os.path.exists(ENCRYPTION_KEY_FILE):
            try:
                with open(ENCRYPTION_KEY_FILE, 'rb') as f:
                    return f.read()
            except Exception as e:
                logger.error(f"加载密钥失败: {e}")
                return self._generate_key()
        else:
            return self._generate_key()
    
    def _generate_key(self) -> bytes:
        """生成新的加密密钥"""
        key = Fernet.generate_key()
        try:
            with open(ENCRYPTION_KEY_FILE, 'wb') as f:
                f.write(key)
            logger.info("已生成新的加密密钥")
        except Exception as e:
            logger.error(f"保存密钥失败: {e}")
        return key
    
    def encrypt_data(self, data: str) -> str:
        """加密数据"""
        try:
            if isinstance(data, str):
                data_bytes = data.encode('utf-8')
            else:
                data_bytes = data
            
            encrypted = self.cipher.encrypt(data_bytes)
            return base64.b64encode(encrypted).decode('utf-8')
        except Exception as e:
            logger.error(f"加密失败: {e}")
            raise
    
    def decrypt_data(self, encrypted_data: str) -> str:
        """解密数据"""
        try:
            encrypted_bytes = base64.b64decode(encrypted_data.encode('utf-8'))
            decrypted = self.cipher.decrypt(encrypted_bytes)
            return decrypted.decode('utf-8')
        except Exception as e:
            logger.error(f"解密失败: {e}")
            raise
    
    def encrypt_file(self, file_path: str, output_path: str = None) -> str:
        """加密文件"""
        if output_path is None:
            output_path = os.path.join(ENCRYPTED_DIR, os.path.basename(file_path) + '.encrypted')
        
        try:
            with open(file_path, 'rb') as f:
                file_data = f.read()
            
            encrypted_data = self.cipher.encrypt(file_data)
            
            with open(output_path, 'wb') as f:
                f.write(encrypted_data)
            
            logger.info(f"文件已加密: {file_path} -> {output_path}")
            return output_path
        except Exception as e:
            logger.error(f"文件加密失败: {e}")
            raise
    
    def decrypt_file(self, encrypted_file_path: str, output_path: str = None) -> str:
        """解密文件"""
        if output_path is None:
            output_path = encrypted_file_path.replace('.encrypted', '')
        
        try:
            with open(encrypted_file_path, 'rb') as f:
                encrypted_data = f.read()
            
            decrypted_data = self.cipher.decrypt(encrypted_data)
            
            with open(output_path, 'wb') as f:
                f.write(decrypted_data)
            
            logger.info(f"文件已解密: {encrypted_file_path} -> {output_path}")
            return output_path
        except Exception as e:
            logger.error(f"文件解密失败: {e}")
            raise
    
    def encrypt_json(self, data: Dict[str, Any]) -> str:
        """加密JSON数据"""
        json_str = json.dumps(data, ensure_ascii=False)
        return self.encrypt_data(json_str)
    
    def decrypt_json(self, encrypted_data: str) -> Dict[str, Any]:
        """解密JSON数据"""
        decrypted_str = self.decrypt_data(encrypted_data)
        return json.loads(decrypted_str)
    
    def hash_password(self, password: str, salt: bytes = None) -> Dict[str, str]:
        """使用PBKDF2哈希密码"""
        if salt is None:
            salt = os.urandom(16)
        
        kdf = PBKDF2HMAC(
            algorithm=hashes.SHA256(),
            length=32,
            salt=salt,
            iterations=100000,
            backend=default_backend()
        )
        
        key = base64.urlsafe_b64encode(kdf.derive(password.encode('utf-8')))
        
        return {
            'hash': key.decode('utf-8'),
            'salt': base64.b64encode(salt).decode('utf-8')
        }
    
    def verify_password(self, password: str, password_hash: str, salt: str) -> bool:
        """验证密码"""
        try:
            salt_bytes = base64.b64decode(salt.encode('utf-8'))
            result = self.hash_password(password, salt_bytes)
            return result['hash'] == password_hash
        except Exception as e:
            logger.error(f"密码验证失败: {e}")
            return False
    
    def create_secure_storage(self, data: Dict[str, Any], filename: str) -> str:
        """创建加密存储文件"""
        encrypted_data = self.encrypt_json(data)
        file_path = os.path.join(ENCRYPTED_DIR, filename)
        
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump({
                'encrypted': True,
                'timestamp': datetime.now().isoformat(),
                'data': encrypted_data
            }, f, ensure_ascii=False, indent=2)
        
        logger.info(f"已创建加密存储: {file_path}")
        return file_path
    
    def read_secure_storage(self, filename: str) -> Dict[str, Any]:
        """读取加密存储文件"""
        file_path = os.path.join(ENCRYPTED_DIR, filename)
        
        with open(file_path, 'r', encoding='utf-8') as f:
            storage = json.load(f)
        
        if storage.get('encrypted'):
            return self.decrypt_json(storage['data'])
        else:
            return storage.get('data', {})


# 全局数据安全实例
data_security = DataSecurity()

