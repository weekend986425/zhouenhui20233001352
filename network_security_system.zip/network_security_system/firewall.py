# -*- coding: utf-8 -*-
"""
防火墙模块 - 实现基于规则的包过滤和攻击阻挡
"""
import json
import logging
import socket
from datetime import datetime
from typing import Dict, List, Tuple
import os
from config import FIREWALL_RULES_FILE, FIREWALL_LOG

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(FIREWALL_LOG, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger('Firewall')


class Firewall:
    """防火墙类 - 实现包过滤和攻击防护"""
    
    def __init__(self):
        self.rules = self.load_rules()
        self.blocked_ips = set()
        self.blocked_ports = set()
        self.attack_patterns = {
            'syn_flood': {'threshold': 10, 'window': 60},  # 60秒内10次SYN请求
            'port_scan': {'threshold': 5, 'window': 30},   # 30秒内扫描5个端口
            'brute_force': {'threshold': 5, 'window': 300} # 5分钟内5次失败登录
        }
        self.connection_tracker = {}  # 跟踪连接
        
    def load_rules(self) -> List[Dict]:
        """加载防火墙规则"""
        default_rules = [
            {
                'id': 1,
                'name': '阻止常见攻击端口',
                'action': 'block',
                'ports': [23, 135, 139, 445, 1433, 3306, 5432],  # Telnet, RPC, SMB, SQL等
                'enabled': True
            },
            {
                'id': 2,
                'name': '阻止已知恶意IP',
                'action': 'block',
                'ips': [],
                'enabled': True
            },
            {
                'id': 3,
                'name': '允许HTTP/HTTPS',
                'action': 'allow',
                'ports': [80, 443, 8080],
                'enabled': True
            },
            {
                'id': 4,
                'name': '阻止SYN Flood攻击',
                'action': 'block',
                'attack_type': 'syn_flood',
                'enabled': True
            },
            {
                'id': 5,
                'name': '阻止端口扫描',
                'action': 'block',
                'attack_type': 'port_scan',
                'enabled': True
            }
        ]
        
        if os.path.exists(FIREWALL_RULES_FILE):
            try:
                with open(FIREWALL_RULES_FILE, 'r', encoding='utf-8') as f:
                    rules = json.load(f)
                    return rules if rules else default_rules
            except Exception as e:
                logger.error(f"加载规则失败: {e}")
                return default_rules
        else:
            self.save_rules(default_rules)
            return default_rules
    
    def save_rules(self, rules: List[Dict] = None):
        """保存防火墙规则"""
        if rules is None:
            rules = self.rules
        try:
            with open(FIREWALL_RULES_FILE, 'w', encoding='utf-8') as f:
                json.dump(rules, f, ensure_ascii=False, indent=2)
            logger.info("防火墙规则已保存")
        except Exception as e:
            logger.error(f"保存规则失败: {e}")
    
    def check_packet(self, src_ip: str, dst_port: int, packet_type: str = 'tcp') -> Tuple[bool, str]:
        """
        检查数据包是否符合规则
        返回: (是否允许, 原因)
        """
        # 检查IP黑名单
        if src_ip in self.blocked_ips:
            logger.warning(f"阻止来自黑名单IP的连接: {src_ip}")
            return False, f"IP {src_ip} 在黑名单中"
        
        # 检查端口黑名单
        if dst_port in self.blocked_ports:
            logger.warning(f"阻止访问被禁端口: {dst_port}")
            return False, f"端口 {dst_port} 被禁止访问"
        
        # 应用规则
        for rule in self.rules:
            if not rule.get('enabled', True):
                continue
                
            action = rule.get('action', 'allow')
            
            # 检查端口规则
            if 'ports' in rule:
                if dst_port in rule['ports']:
                    if action == 'block':
                        logger.warning(f"规则 {rule['name']} 阻止端口 {dst_port}")
                        return False, f"规则阻止: {rule['name']}"
                    elif action == 'allow':
                        return True, f"规则允许: {rule['name']}"
            
            # 检查IP规则
            if 'ips' in rule:
                if src_ip in rule['ips']:
                    if action == 'block':
                        logger.warning(f"规则 {rule['name']} 阻止IP {src_ip}")
                        return False, f"规则阻止: {rule['name']}"
        
        # 默认允许
        return True, "通过防火墙检查"
    
    def detect_syn_flood(self, src_ip: str) -> bool:
        """检测SYN Flood攻击"""
        pattern = self.attack_patterns['syn_flood']
        current_time = datetime.now().timestamp()
        
        if src_ip not in self.connection_tracker:
            self.connection_tracker[src_ip] = {'syn_requests': []}
        
        # 清理旧记录
        self.connection_tracker[src_ip]['syn_requests'] = [
            t for t in self.connection_tracker[src_ip]['syn_requests']
            if current_time - t < pattern['window']
        ]
        
        # 添加新请求
        self.connection_tracker[src_ip]['syn_requests'].append(current_time)
        
        # 检查是否超过阈值
        if len(self.connection_tracker[src_ip]['syn_requests']) >= pattern['threshold']:
            logger.critical(f"检测到SYN Flood攻击来自: {src_ip}")
            self.block_ip(src_ip, "SYN Flood攻击")
            return True
        return False
    
    def detect_port_scan(self, src_ip: str, dst_port: int) -> bool:
        """检测端口扫描"""
        pattern = self.attack_patterns['port_scan']
        current_time = datetime.now().timestamp()
        
        if src_ip not in self.connection_tracker:
            self.connection_tracker[src_ip] = {'scanned_ports': {}}
        
        if 'scanned_ports' not in self.connection_tracker[src_ip]:
            self.connection_tracker[src_ip]['scanned_ports'] = {}
        
        # 清理旧记录
        self.connection_tracker[src_ip]['scanned_ports'] = {
            port: time for port, time in self.connection_tracker[src_ip]['scanned_ports'].items()
            if current_time - time < pattern['window']
        }
        
        # 添加新扫描
        self.connection_tracker[src_ip]['scanned_ports'][dst_port] = current_time
        
        # 检查是否超过阈值
        if len(self.connection_tracker[src_ip]['scanned_ports']) >= pattern['threshold']:
            logger.critical(f"检测到端口扫描来自: {src_ip}")
            self.block_ip(src_ip, "端口扫描")
            return True
        return False
    
    def block_ip(self, ip: str, reason: str):
        """阻止IP地址"""
        self.blocked_ips.add(ip)
        logger.warning(f"已阻止IP: {ip}, 原因: {reason}")
    
    def unblock_ip(self, ip: str):
        """解除IP阻止"""
        if ip in self.blocked_ips:
            self.blocked_ips.remove(ip)
            logger.info(f"已解除IP阻止: {ip}")
    
    def block_port(self, port: int):
        """阻止端口"""
        self.blocked_ports.add(port)
        logger.info(f"已阻止端口: {port}")
    
    def get_statistics(self) -> Dict:
        """获取防火墙统计信息"""
        return {
            'blocked_ips_count': len(self.blocked_ips),
            'blocked_ports_count': len(self.blocked_ports),
            'rules_count': len(self.rules),
            'active_rules': len([r for r in self.rules if r.get('enabled', True)]),
            'blocked_ips': list(self.blocked_ips),
            'blocked_ports': list(self.blocked_ports)
        }


# 全局防火墙实例
firewall = Firewall()

