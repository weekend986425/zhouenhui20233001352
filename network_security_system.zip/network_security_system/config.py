# -*- coding: utf-8 -*-
"""
网络安全系统配置文件
"""
import os

# 服务器配置
SERVER_HOST = '0.0.0.0'  # 监听所有网络接口
SERVER_PORT = 8080

# 数据存储路径
DATA_DIR = 'data'
RULES_DIR = os.path.join(DATA_DIR, 'rules')
LOGS_DIR = os.path.join(DATA_DIR, 'logs')
ENCRYPTED_DIR = os.path.join(DATA_DIR, 'encrypted')

# 创建必要的目录
for directory in [DATA_DIR, RULES_DIR, LOGS_DIR, ENCRYPTED_DIR]:
    os.makedirs(directory, exist_ok=True)

# 防火墙规则文件
FIREWALL_RULES_FILE = os.path.join(RULES_DIR, 'firewall_rules.json')

# IDS规则文件
IDS_RULES_FILE = os.path.join(RULES_DIR, 'ids_rules.json')

# 密码策略配置
PASSWORD_POLICY = {
    'min_length': 8,
    'require_uppercase': True,
    'require_lowercase': True,
    'require_digits': True,
    'require_special': True,
    'max_age_days': 90
}

# 加密配置
ENCRYPTION_KEY_FILE = os.path.join(DATA_DIR, 'encryption_key.key')

# 日志文件
FIREWALL_LOG = os.path.join(LOGS_DIR, 'firewall.log')
IDS_LOG = os.path.join(LOGS_DIR, 'ids.log')
SECURITY_LOG = os.path.join(LOGS_DIR, 'security.log')

